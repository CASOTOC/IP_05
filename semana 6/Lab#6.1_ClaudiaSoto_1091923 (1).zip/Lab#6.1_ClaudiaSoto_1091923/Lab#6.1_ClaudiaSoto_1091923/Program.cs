﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6._1_ClaudiaSoto_1091923
{
    internal class Program
    {
        static void Main(string[] args)
        {
                // Mostrar el mensaje del ejercicio 1
                Console.WriteLine("Ejercicio 1: Operaciones Aritméticas");

                // Permitir al usuario ingresar dos números y convertirlos a tipos de datos adecuados
                Console.Write("Ingrese el primer número: ");
                double numero1 = Convert.ToDouble(Console.ReadLine());

                Console.Write("Ingrese el segundo número: ");
                double numero2 = Convert.ToDouble(Console.ReadLine());

                // Realizar las operaciones aritméticas y almacenar los resultados
                double suma = numero1 + numero2;
                double resta = numero1 - numero2;
                double multiplicacion = numero1 * numero2;

                // Manejo de la división por cero
                double division, div, mod;
                if (numero2 != 0)
                {
                    division = numero1 / numero2;
                    div = Math.Floor(numero1 / numero2); // División entera
                    mod = numero1 % numero2; // Módulo (residuo)
                }
                else
                {
                    Console.WriteLine("No es posible dividir por cero.");
                    return;
                }

                // Mostrar los resultados de las operaciones aritméticas
                Console.WriteLine(numero1 + “+” +numero2 + “=” suma);
                Console.WriteLine(numero1 + “-“ +numero2 + “=” +resta);
                Console.WriteLine(numero1 + “*” +numero2 + “=” +multiplicacion);
                Console.WriteLine(numero1 + “/” +numero2 “= " + division);
        
                Console.WriteLine(numero1 + “div” +numero2 “=” div);
                Console.WriteLine(numero1 + “mod” +numero2 + “ = “ +mod);

                // Nuevo mensaje del ejercicio 2
                Console.WriteLine("\nEjercicio 2: Operaciones Booleanas");

                // Operaciones booleanas
                bool mayorQue = numero1 > numero2;
                bool menorQue = numero1 < numero2;
                bool igual = numero1 == numero2;

                // Mostrar los resultados de las operaciones booleanas
                Console.WriteLine(numero1 +  “ >” numero2 + “=” +mayorQue);
                Console.WriteLine(numero1 + “<” numero2 + “=” +menorQue);
                Console.WriteLine(numero1 + “==” +numero2 +“=” +igual);

                // Nuevo mensaje del ejercicio 3
                Console.WriteLine("\nEjercicio 3: Jerarquía de Operaciones");

                // Permitir al usuario ingresar tres números
                Console.Write("Ingrese el primer número (a): ");
                double a = Convert.ToDouble(Console.ReadLine());

                Console.Write("Ingrese el segundo número (b): ");
                double b = Convert.ToDouble(Console.ReadLine());

                Console.Write("Ingrese el tercer número (c): ");
                double c = Convert.ToDouble(Console.ReadLine());

                // Calcular y mostrar los resultados de las expresiones adicionales
                double resultado1 = a * b + c;
                double resultado2 = a * (b + c);
                double resultado3 = a / (b * c);
                double resultado4 = (3 * a + 2 * b) / Math.Pow(c, 2);

                Console.WriteLine(a + “*” +b + “+”+c +“=” +resultado1);
                Console.WriteLine(a + “*” + “(“+b + “+” +c + “) =” resultado2);
                Console.WriteLine(a “/” + “(“+b + “*” +c + “) =” +resultado3);
                Console.WriteLine(“(3 *” +a + “2 *” +b + “) /”+c + “^2 =”+resultado4);
            }
        }
    }
 