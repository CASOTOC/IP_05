﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;

namespace Lab_6._2_ClaudiaSoto_1091923
{
    internal class Program
    {
       
            static void Main()
            {
                // Mostrar el mensaje del ejercicio 3
                Console.WriteLine("Ejercicio 3: Jerarquía de Operaciones");

                // Permitir al usuario ingresar tres números
                Console.Write("Ingrese el valor de a (debe ser distinto de 0): ");
                double a = Convert.ToDouble(Console.ReadLine());

                Console.Write("Ingrese el valor de b: ");
                double b = Convert.ToDouble(Console.ReadLine());

                Console.Write("Ingrese el valor de c: ");
                double c = Convert.ToDouble(Console.ReadLine());

                // Verificar condiciones ideales
                if (a != 0 && Math.Pow(b, 2) - 4 * a * c >= 0)
                {
                    // Calcular el discriminante
                    double discriminante = Math.Pow(b, 2) - 4 * a * c;

                    // Calcular las dos soluciones
                    double x1 = (-b + Math.Sqrt(discriminante)) / (2 * a);
                    double x2 = (-b - Math.Sqrt(discriminante)) / (2 * a);

                    // Mostrar las soluciones
                    Console.WriteLine("Solución 1: x =”+ x1);
        
                    Console.WriteLine("Solución 2: x =” + x2);
                }
                else
                {
                    Console.WriteLine("Error: a debe ser distinto de 0 y b^2 - 4ac debe ser mayor o igual a 0.");
                }
            }
        }
    }
  