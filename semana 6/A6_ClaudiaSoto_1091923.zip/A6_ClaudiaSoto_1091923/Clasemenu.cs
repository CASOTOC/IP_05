﻿

class Clasemenu
{ static void Main(string[] args)
    { Console.WriteLine("Programa de salarios de empleados");
        Console.WriteLine("Seleccione opción de área de trabajo");
        Console.WriteLine("Menú de áreas de trabajo");
        Console.WriteLine("1 área administrativa");
        Console.WriteLine("2 mercadeo"); 
        Console.WriteLine("3 ventas");
        Console.WriteLine("4 limpieza");
        Console.WriteLine("5 logística");
        string opcion = Console.ReadLine();
       switch (opcion)
        {
            case "1":
                Console.WriteLine("Selecciono opción: " + opcion + " área administrativa");
                break;
            case "2":
                Console.WriteLine("Selecciono opción: " + opcion + " mercadeo");
                break;

            case "3":
                Console.WriteLine("Selecciono opción: " + opcion+ " ventas");
                break;

            case "4":
                Console.WriteLine("Selecciono opción: " + opcion + " limpieza");
                break;

            case "5":
                Console.WriteLine("Selecciono opción: " + opcion + " logísica");
                break;
            default:
                Console.WriteLine("Selecciono una opción invalida");
                break;
       } // termina instrucción de switch
      
        Console.ReadKey();
    }
    
    }





