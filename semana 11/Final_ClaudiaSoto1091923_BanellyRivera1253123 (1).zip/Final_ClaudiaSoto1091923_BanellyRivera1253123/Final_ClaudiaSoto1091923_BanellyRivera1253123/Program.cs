﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prueba1
{
    using System;

    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("Salario de empleados de la empresa");
            Console.WriteLine("Este programa está creado para permitir al usuario calcular el salario de cada empleado de la empresa, según el área de trabajo y el tipo de empleo.");

            while (true)
            {
                Console.WriteLine("\nPágina de inicio");
                Console.WriteLine("Menú principal:");
                Console.WriteLine("1. Proceso principal");
                Console.WriteLine("2. Manual de usuario");
                Console.WriteLine("3. Créditos");
                Console.WriteLine("4. Salir");

                Console.Write("Seleccione una opción: ");
                int opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine("\nProceso principal:");
                        Console.Write("Lo primero para calcular el salario es que debe ingresar su nombre: ");
                        string nombre = Console.ReadLine();
                        Console.Write("Escoja el área de trabajo en la que se desempeña:\n1. Área administrativa\n2. Área de logística\n3. Área de limpieza\n4. Área de producción\n5. Área de ventas\nSeleccione el número correspondiente: ");
                        int opcionArea = int.Parse(Console.ReadLine());
                        string area = "";

                        switch (opcionArea)
                        {
                            case 1:
                                area = "Área administrativa";
                                break;
                            case 2:
                                area = "Área de logística";
                                break;
                            case 3:
                                area = "Área de limpieza";
                                break;
                            case 4:
                                area = "Área de producción";
                                break;
                            case 5:
                                area = "Área de ventas";
                                break;
                            default:
                                Console.WriteLine("Área no válida. Seleccione una opción válida.");
                                return;
                        }

                        Console.Write("Seleccione el tipo de turno laborado:\n1. Jornada completa\n2. Media jornada\nSeleccione el número correspondiente: ");
                        int opcionJornada = int.Parse(Console.ReadLine());
                        string jornada = "";

                        switch (opcionJornada)
                        {
                            case 1:
                                jornada = "Jornada completa";
                                break;
                            case 2:
                                jornada = "Media jornada";
                                break;
                            default:
                                Console.WriteLine("Jornada no válida. Seleccione una opción válida.");
                                return;
                        }

                        double salario = CalcularSalario(area, jornada);
                        Console.WriteLine($"Estimad@ {nombre}, que labora en el {area} y que su jornada es {jornada}, su salario es de Q{salario:F2}.");
                        MenuResultados(nombre, area, jornada, salario);
                        break;
                    case 2:
                        ManualUsuario();
                        break;
                    case 3:
                        MostrarCreditos();
                        break;
                    case 4:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            }
        }

        static void ProcesoPrincipal()
        {

        }

        static double CalcularSalario(string area, string jornada)
        {
            switch (area)
            {
                case "Área administrativa":
                    return jornada == "Jornada completa" ? 8000.00 : 6000.00;
                case "Área de logística":
                    return jornada == "Jornada completa" ? 10000.00 : 8500.00;
                case "Área de limpieza":
                    return jornada == "Jornada completa" ? 3800.00 : 2605.00;
                case "Área de producción":
                    return jornada == "Jornada completa" ? 5170.00 : 4700.00;
                case "Área de ventas":
                    return jornada == "Jornada completa" ? 4500.00 : 3700.00;
                default:
                    return 0.00;
            }
        }

        static void MenuResultados(string nombre, string area, string jornada, double salario)
        {
            while (true)
            {
                Console.WriteLine("\nMenú de resultados:");
                Console.WriteLine("1. Mostrar resultados");
                Console.WriteLine("2. Regresar al menú principal");
                Console.WriteLine("3. Salir");

                Console.Write("Seleccione una opción: ");
                int opcion = int.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.WriteLine($"Estimad@, los resultados son los siguientes:\nNombre: {nombre}\nÁrea: {area}\nJornada: {jornada}\nSalario: Q{salario:F2}");
                        break;
                    case 2:
                        return;
                    case 3:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Opción no válida. Por favor, seleccione una opción válida.");
                        break;
                }
            }
        }

        static void ManualUsuario()
        {
            Console.WriteLine("\nManual de usuario:");
            Console.WriteLine("Este programa posee 3 distintos menús...");
            Console.WriteLine("La función principal de este programa es poder calcular el salario de cada empleado según su área de trabajo y el horario en el que trabaje.");
        }

        static void MostrarCreditos()
        {
            Console.WriteLine("\nCréditos:");
            Console.WriteLine("Salario de empleados de la empresa");
            Console.WriteLine("Creado el 22 de octubre de 2023");
            Console.WriteLine("Horas invertidas: 8 horas");
            Console.WriteLine("Creadoras:");
            Console.WriteLine("Banelly Rivera 1253123 Ingeniería Industrial");
            Console.WriteLine("Claudia Soto 1091923 Ingeniera Industrial");
        }
    }
}