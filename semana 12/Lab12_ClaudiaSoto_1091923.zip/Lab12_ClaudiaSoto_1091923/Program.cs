﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab12_ClaudiaSoto_1091923
{
    class Circulo
    {
        // Atributo privado
        private double radio;

        // Constructor
        public Circulo(double radio)
        {
            this.radio = radio;
        }

        // Método privado para obtener el perímetro
        private double ObtenerPerimetro()
        {
            return 2 * Math.PI * radio;
        }

        // Método privado para obtener el área
        private double ObtenerArea()
        {
            return Math.PI * Math.Pow(radio, 2);
        }

        // Método privado para obtener el volumen
        private double ObtenerVolumen()
        {
            // El volumen de una esfera se calcula como (4/3) * Pi * radio^3
            return (4.0 / 3.0) * Math.PI * Math.Pow(radio, 3);
        }

        // Método público para calcular la geometría y actualizar los valores
        public void CalcularGeometria(ref double unPerimetro, ref double unArea, ref double unVolumen)
        {
            unPerimetro = ObtenerPerimetro();
            unArea = ObtenerArea();
            unVolumen = ObtenerVolumen();
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // Declarar un objeto Circulo
            Circulo objCirculo;

            // Solicitar al usuario el radio del círculo
            Console.Write("Ingrese el radio del círculo: ");
            double radio = Convert.ToDouble(Console.ReadLine());

            // Declarar variables para almacenar los resultados
            double perimetro = 0;
            double area = 0;
            double volumen = 0;

            // Crear un objeto Circulo con el radio proporcionado por el usuario
            objCirculo = new Circulo(radio);

            // Calcular la geometría y actualizar los valores
            objCirculo.CalcularGeometria(ref perimetro, ref area, ref volumen);

            // Mostrar la información
            Console.WriteLine("Información del círculo:");
            Console.WriteLine("Perímetro: " + perimetro);
            Console.WriteLine("Área: " + area);
            Console.WriteLine("Volumen de la esfera: " + volumen);

            Console.ReadLine();
        }
    }
}
