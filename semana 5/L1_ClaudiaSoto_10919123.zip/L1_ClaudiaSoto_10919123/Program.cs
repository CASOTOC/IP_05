﻿class program
{
    static void Main (string[] args)
    {
        Console.WriteLine("Ingrese su nombre");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola mundo");
        Console.WriteLine(" Soy " + Nombre);
        /* este es un ejemplo de comentario en varias lineas
         */
        // este es un comen en una linea 
        Console.Write(" hola mundo ");
        Console.Write("soy "+ Nombre);
        Console.ReadKey();
    }



}
