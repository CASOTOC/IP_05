﻿class program
{
    static void Main(string[] args)
    {

        Console.WriteLine("Mi segundo programa ");
        string sNombre, sedad, sCarrera, scarne = Console.ReadLine();

        // Ingrese su nombre
        Console.WriteLine("Ingrese nombre");
        sNombre = Console.ReadLine();
        Console.ReadKey();

        // Ingrese su edad
        Console.WriteLine("Ingrese edad");
        sedad = Console.ReadLine();
        Console.ReadKey();


        //Ingrese su carrera 
        Console.WriteLine("Ingrese Carrera");
        sCarrera = Console.ReadLine();
        Console.ReadKey();

        // Ingrese su carne
        Console.WriteLine("Ingrese Carne");
        scarne = Console.ReadLine();
        Console.ReadKey();

        Console.WriteLine("Mi segundo programa");
        Console.WriteLine("Nombre " + sNombre);
        Console.WriteLine("mi edad " + sedad);
        Console.WriteLine("mi carrera " + sCarrera);
        Console.WriteLine("mi carrne " + scarne);
        Console.ReadKey();

        Console.WriteLine();
        Console.WriteLine("Soy  " + sNombre + "tengo " + sedad + " años y estudio " + sCarrera );
        Console.WriteLine("Mi numero de carne es  " + scarne);
        Console.ReadKey();

    }
}


